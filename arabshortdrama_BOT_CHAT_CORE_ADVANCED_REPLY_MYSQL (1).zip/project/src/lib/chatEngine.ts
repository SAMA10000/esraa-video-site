// Full Arabic/Egyptian Slang NLP Chat Engine
// 100+ unique usernames, 5 conversational domains with probabilistic steering

// 100+ unique Arabic/Egyptian usernames
export const BOT_USERNAMES: string[] = [
  'أحمد المصري', 'كريم السلام', 'سلطان الغالي', 'يوسف حبيب', 'محمد السيد',
  'عمر الفنان', 'خالد المعلم', 'فهد الكبير', 'ماجد الروح', 'راشد الحلو',
  'سعد البرنس', 'ناصر القاهري', 'عبدالله الجن', 'حمد الشاطر', 'زياد المحظوظ',
  'طارق الملك', 'بدر النجم', 'فاروق البطل', 'سمير الحب', 'علي الزعيم',
  'فاطمة ست الدار', 'نور السهر', 'سارة القمر', 'هدى العسل', 'مريم الفنانة',
  'ليلى الشرق', 'دينا الروح', 'رنا الحلوة', 'منى القلب', 'أميرة الدينا',
  'أكمل العرب', 'حمزة الصقر', 'إسلام النمر', 'مصطفى الأسد', 'عادل الحقيقي',
  'سيف العدل', 'رمضان الصايم', 'حسام الفارس', 'وليد المالك', 'هشام الراشد',
  'طه الهدى', 'زين العابدين', 'كامل التام', 'راغب الحب', 'منصور النصر',
  'نادر النادر', 'صلاح الدين', 'ياسر السلام', 'جمال الجمال', 'حازم الحازم',
  'شريف الشريف', 'مجدي المجد', 'كمال الكمال', 'عزت العزة', 'فتحي الفتوح',
  'رضا الراضي', 'حسني الحسن', 'جمال الدين', 'أنور النور', 'بهاء البهاء',
  'هند الجميلة', 'شيماء الشمس', 'أسماء النجوم', 'إيمان الإيمان', 'روان الروح',
  'دانا الدلوعة', 'لمياء الليل', 'بسمة الفرحة', 'زينب الزينة', 'آية المعجزة',
  'وسام الوسام', 'هاني الهانى', 'جلال الجلال', 'دكتور أيمن', 'مهند المهندس',
  'عمرو عمرو', 'تامر التامر', 'شادي الشادي', 'حبيب الحبيب', 'صلاح الصلاح',
  'مريم البتول', 'ياسمين الياسمين', 'وردة الورد', 'عبير العبير', 'حلاوة الحلاوة',
  'ريم الريم', 'غادة الغادة', 'نجلاء النجلاء', 'شيرين الشيرين', 'إسراء الإسراء',
  'فادي الفادي', 'نديم النديم', 'رامي الرامي', 'سامي السامي', 'نايم النعيم',
  'فوزي الفوزي', 'جمعة الجمعة', 'سيد السيد', 'عبد الرحمن', 'محمدين المصري',
  'أبو خالد', 'أبو يوسف', 'أبو سلطان', 'أبو محمد', 'أبو عمر',
  'أبو خالد الحجازي', 'يوسف_99', 'بنوتة_كول', 'كينج_الدراما', 'سوليفان_الأسطوري',
  'برنس_المصري', 'دكتورة_نور', 'ست_الكل', 'ملكة_الشات', 'فنان_العرب',
];

// Domain keyword maps
const EPISODE_LINKS_KEYWORDS = [
  'فين', 'حلقة', 'مسلسل', 'شغال', 'ازاي', 'شغل',
  'الحلقه', 'الحلقات', 'السيرفر', 'كامل', 'ناقص', 'الباقي',
  'اليوتيوب', 'تيكتوك', 'الموقع', 'الصفحة',
];

const DRAMA_CONTENT_KEYWORDS = [
  'البطل', 'البطلة', 'انتقام', 'صعود', 'نفوذ', 'قوة', 'متخفي', 'نهاية',
  'صدمة', 'حماس', 'الممثل', 'الحكاية', 'خيانة', 'فلوس', 'جوزها', 'مراتة',
  'موت', 'قتل', 'حقير', 'جامد',
];

const GAMES_APPS_KEYWORDS = [
  'لعبة', 'العبه', 'جيم', 'تطبيق', 'برنامج', 'ببجي',
  'اللعبه', 'الجيم', 'فيفا', 'تلفون', 'موبايل',
];

const TRUST_SECURITY_KEYWORDS = [
  'نصب', 'كذب', 'حقيقي', 'بجد', 'شغال فعلا', 'امان', 'بفلوس', 'رصيد',
  'اشتراك', 'بيسحب', 'سحب', 'فيزا', 'حرام', 'اشتغلت', 'معايا', 'الهوية',
];

const GENERAL_CHAT_KEYWORDS = [
  'سلام', 'عليكم', 'هلا', 'مرحب', 'شباب', 'بنات', 'منورين', 'الموقع',
  'جديد', 'كلان', 'جروب', 'شات', 'مين', 'موجود', 'معايا', 'سهرة', 'مساء',
];

type Domain = 'episode_links' | 'drama_content' | 'games_apps' | 'trust_security' | 'general_chat';

// Neutral bot templates only: no sponsor/partner/activation/link-management language.
const DOMAIN_TEMPLATES: Record<Domain, string[][]> = {
  episode_links: [
    ['الحلقات الكاملة', 'مترتبة في الصفحة', 'تابعوا من نفس المشغل', 'والتجربة واضحة للجميع'],
    ['يا جماعة عشان تشوفوا الباقي', 'اختاروا الحلقة من الصفحة', 'كل حاجة مرتبة', 'ومفيش أي كلام خارجي'],
    ['السيرفر مستقر', 'والصفحة بتعرض المحتوى', 'تابعوا الأحداث', 'واكتبوا رأيكم في الشات'],
    ['مفيش بيانات تواصل في الشات', 'خلونا في المسلسل', 'والحلقات هتفضل منظمة', 'قدامكم في الصفحة'],
    ['اللي عايز الباقي', 'يتابع الترشيحات', 'نفس القسم مليان حاجات قوية', 'والاختيار سهل'],
    ['الموقع شغال', 'والتجربة هادئة', 'اختاروا المسلسل', 'وكملوا مشاهدة براحتكم'],
    ['الحلقات موجودة بترتيب واضح', 'والترشيحات بتساعد', 'اختاروا من نفس القسم', 'هتلاقوا حاجات شبهه'],
    ['كل اللي يهمنا هنا', 'الكلام عن الأحداث', 'من غير أرقام أو روابط', 'عشان الشات يفضل آمن'],
    ['المسلسل كامل في الصفحة', 'والتفاصيل واضحة', 'والترشيحات تحت', 'لو عايزين حاجة شبهه'],
    ['يا شباب', 'ركزوا في الأحداث', 'الشات للآراء', 'والترشيحات تحت المشغل'],
  ],
  drama_content: [
    ['البطل ده', 'جامد جدا', 'شخصية صعبة', 'مش متوقع النهاية دي خالص'],
    ['والله القصة دي', 'تشدد الأعصاب', 'مجنونة', 'كل حلقة أحسن من اللي قبلها'],
    ['الخيانة دي', 'صدمتني', 'مرة وحشة', 'ماتوقعتهاش من الشخصية دي'],
    ['الممثل الرئيسي', 'أبدع', 'شغل عالي', 'أداؤه في المشهد ده فوق الوصف'],
    ['الحكاية كلها عن', 'الانتقام والصعود', 'القوة والنفوذ', 'مسلسل يستحق المشاهدة'],
    ['نهاية الحلقة دي', 'فاجأتني', 'مستحيلة', 'مش ممكن ده يحصل بجد'],
    ['البطلة', 'عملت حاجة غريبة', 'في المشهد الأخير', 'ده مش مسلسل ده فيلم'],
    ['الأخ الغدار', 'خان العيلة كلها', 'عشان الفلوس', 'شخصية صعبة أوي'],
    ['مشهد الانتقام', 'كان رهيب', 'البطل رجع بقوة', 'ده أحسن مسلسل شفته'],
    ['القصة بتتشعب', 'كل حلقة بتفاجئنا', 'في خيانة جديدة', 'مش عارف مين الثقة ومين العدو'],
  ],
  games_apps: [
    ['أنا بجرب', 'اللعبة دي', 'بين الحلقات', 'ومسلية بصراحة'],
    ['يا شباب', 'الجيم ده', 'حلو وخفيف', 'حد جربه قبل كده؟'],
    ['نصيحة', 'جربت اللعبة', 'على الموبايل', 'ومش واخدة مساحة كبيرة'],
    ['اللعبة دي', 'شغالة كويس', 'ومناسبة للانتظار', 'بين حلقة والتانية'],
    ['جربت', 'اللعبة الجديدة', 'شغل لطيف', 'خصوصاً وقت الفواصل'],
    ['يا جماعة', 'التطبيق ده', 'فكرته حلوة', 'ينفع مع متابعة المسلسلات'],
    ['اللعبة', 'خفيفة ومسلية', 'ومش محتاجة تركيز كبير', 'بعد الحلقة جامدة'],
    ['أنا بلعب', 'الجيم ده', 'من يومين', 'ومناسب وقت السهرة'],
    ['اللعبة دي', 'ناس كتير بتتكلم عنها', 'حد وصل مستوى عالي؟', 'شاركونا رأيكم'],
    ['البرنامج ده', 'فكرته بسيطة', 'ومفيد لبعض الناس', 'حسب استخدامك'],
  ],
  trust_security: [
    ['يا جماعة الموقع', 'تجربته هادئة', 'ومفيش داعي لكتابة أرقام', 'خلينا في الكلام عن المسلسل'],
    ['المهم في الشات', 'مفيش بيانات تواصل', 'ولا كلام مخالف', 'عشان المكان يفضل آمن'],
    ['مفيش داعي للخروج عن الموضوع', 'اتكلموا عن الحلقة', 'والإدارة بتراجع المخالف', 'عشان الكل يرتاح'],
    ['لا تقلقوا', 'الشات معمول للمتابعة', 'والكلام عن الأحداث', 'مش لمشاركة بيانات شخصية'],
    ['الحماية هنا', 'عشان تمنع الإزعاج', 'والأرقام والروابط بتترفض', 'بشكل تلقائي'],
    ['أنا كنت خايف', 'بس التجربة هادئة', 'والصفحة واضحة', 'ومفيش حاجة غريبة'],
    ['خلينا آمنين', 'من غير أرقام', 'ومن غير حسابات تواصل', 'واتكلموا عن المسلسل'],
    ['أي كلام مخالف', 'مش هينزل', 'وده أحسن للكل', 'عشان الشات يفضل محترم'],
    ['يا شباب لا تقلقوا', 'الشات بسيط', 'والتعليقات النظيفة بتعدي', 'من غير مشاكل'],
    ['القواعد بسيطة', 'مفيش أرقام ولا روابط', 'والباقي كله دردشة عادية', 'عن المسلسل'],
  ],
  general_chat: [
    ['سلام يا', 'شباب', 'منورين الموقع', 'سهرة حلوة لكل الناس'],
    ['مساء الخير', 'يا أصدقاء', 'المكان ده جامد', 'كلنا هنا بنستمتع'],
    ['هلا والله', 'مين موجود', 'الشات شغال', 'يلا نتفاعل'],
    ['أهلاً بالجميع', 'الموقع جديد وحلو', 'كلنا هنستفيد', 'يلا نشوف المسلسلات'],
    ['مرحب يا', 'جروب', 'منورين السهرة', 'بنشوف حاجة حلوة النهاردة'],
    ['يا شباب', 'المساء فليل', 'كلنا هنا بنتفرج', 'يلا كومنتات'],
    ['منورين يا ناس', 'الشات حي', 'مين قاعد معايا', 'سهرة حماسية'],
    ['أهلين بالجميع', 'بنشوف مسلسلات', 'وبنستمتع', 'يلا يا شباب'],
    ['مساء الفل', 'يا عالم', 'كلنا هنا عشان المسلسلات', 'يلا نشوف'],
    ['هاي شباب', 'الموقع ده جامد', 'كل حاجة شغالة', 'يلا نتفاعل'],
  ],
};

// Neutral synonym map; no partner/sponsor/activation wording.
const SYNONYM_MAP: Record<string, string[]> = {
  'جامد جدا': ['جامد جدا', 'رهيب', 'عظيم', 'تحفة', 'خرافي', 'مميز'],
  'شخصية صعبة': ['شخصية صعبة', 'شخصية شريرة', 'شخصية معقدة', 'مش سهل', 'خبيث'],
  'تشدد الأعصاب': ['تشدد الأعصاب', 'تشوق', 'تخليك تتفرج', 'تجنن', 'مش سهلة'],
  'مجنونة': ['مجنونة', 'خطيرة', 'رهيبة', 'جامدة', 'ماتتوقعهاش', 'غريبة'],
  'صدمتني': ['صدمتني', 'فاجأتني', 'جننتني', 'ماكنتش متوقعها', 'بهارتني'],
  'أبدع': ['أبدع', 'أحسن أداء', 'تمثيل عالي', 'جامد في التمثيل', 'أداء خرافي', 'شغل نادر'],
  'اللعبة دي': ['اللعبة دي', 'الجيم ده', 'التطبيق ده', 'البرنامج ده', 'اللعبة الجديدة'],
  'حلو وخفيف': ['حلو وخفيف', 'مسلي', 'لطيف', 'مناسب للانتظار', 'سهل الاستخدام'],
  'شغالة كويس': ['شغالة كويس', 'تجربتها كويسة', 'مناسبة', 'خفيفة', 'لطيفة'],
  'تجربة هادئة': ['تجربة هادئة', 'تجربة منظمة', 'تصفح مريح', 'متابعة سهلة'],
  'شباب': ['شباب', 'أصدقاء', 'جماعة', 'ناس', 'كلنا', 'عالم'],
  'منورين الموقع': ['منورين الموقع', 'منورين الشات', 'أهلاً بيكم', 'نورتوا', 'حياكم الله', 'أهلين'],
  'مين موجود': ['مين موجود', 'مين شغال', 'فين الناس', 'مين معايا', 'مين قاعد', 'مين معانا'],
};

function replaceSynonyms(template: string[]): string[] {
  return template.map((phrase) => {
    const synonyms = SYNONYM_MAP[phrase];
    if (synonyms) {
      return synonyms[Math.floor(Math.random() * synonyms.length)];
    }
    return phrase;
  });
}

function constructSentence(template: string[]): string {
  const parts = replaceSynonyms(template);
  // Add slight random reordering for parts that aren't positional
  return parts.join(' ');
}

function detectDomain(text: string): Domain | null {
  const lower = text.toLowerCase();
  for (const kw of EPISODE_LINKS_KEYWORDS) { if (lower.includes(kw)) return 'episode_links'; }
  for (const kw of DRAMA_CONTENT_KEYWORDS) { if (lower.includes(kw)) return 'drama_content'; }
  for (const kw of GAMES_APPS_KEYWORDS) { if (lower.includes(kw)) return 'games_apps'; }
  for (const kw of TRUST_SECURITY_KEYWORDS) { if (lower.includes(kw)) return 'trust_security'; }
  for (const kw of GENERAL_CHAT_KEYWORDS) { if (lower.includes(kw)) return 'general_chat'; }
  return null;
}

export interface BotRuntimeConfig {
  knowledgeBase: string;
  targetGame: string;
  steeringWeight: number;
}

export const DEFAULT_BOT_RUNTIME_CONFIG: BotRuntimeConfig = {
  knowledgeBase: '',
  targetGame: 'لعبة ببجي الجديدة',
  steeringWeight: 15,
};

let runtimeBotConfig: BotRuntimeConfig = { ...DEFAULT_BOT_RUNTIME_CONFIG };

export function setRuntimeBotConfig(config: Partial<BotRuntimeConfig>) {
  runtimeBotConfig = {
    knowledgeBase: config.knowledgeBase ?? DEFAULT_BOT_RUNTIME_CONFIG.knowledgeBase,
    targetGame: config.targetGame ?? DEFAULT_BOT_RUNTIME_CONFIG.targetGame,
    steeringWeight: Math.max(0, Math.min(100, Number(config.steeringWeight ?? DEFAULT_BOT_RUNTIME_CONFIG.steeringWeight))),
  };
}

export async function fetchPublicBotSettings(): Promise<BotRuntimeConfig & { feedEnabled: boolean; pollingInterval: number; reservedNames?: string[]; lastUpdatedAt?: string | null; timeContext?: Record<string, unknown>; brain?: Record<string, unknown> }> {
  const response = await fetch('/api/public/bot-settings.php?ts=' + Date.now(), { headers: { Accept: 'application/json' }, credentials: 'include' });
  const json = await response.json();
  const data = json?.data || json || {};
  const config = {
    knowledgeBase: String(data.knowledgeBase || ''),
    targetGame: String(data.targetGame || DEFAULT_BOT_RUNTIME_CONFIG.targetGame),
    steeringWeight: Math.max(0, Math.min(100, Number(data.steeringWeight ?? DEFAULT_BOT_RUNTIME_CONFIG.steeringWeight))),
    feedEnabled: data.feedEnabled !== false,
    pollingInterval: Math.max(5, Math.min(60, Number(data.pollingInterval || 10))),
    reservedNames: Array.isArray(data.reservedNames) ? data.reservedNames : undefined,
    lastUpdatedAt: data.lastUpdatedAt || null,
    timeContext: data.timeContext || undefined,
    brain: data.brain || undefined,
  };
  setRuntimeBotConfig(config);
  return config;
}

export interface ChatMessage {
  id: string;
  dbId?: number;
  username: string;
  text: string;
  isBot: boolean;
  isMine?: boolean;
  domain?: Domain;
  timestamp: number;
  humanDelay?: number;
  profile?: { id?: number | null; persona?: string; speechStyle?: string };
  timeContext?: Record<string, unknown>;
  memoryUsed?: number;
  replyToMessageId?: number | null;
  dramaId?: number | null;
}

// Track used usernames to prevent immediate repetition
const recentUsernames: string[] = [];
const MAX_RECENT = 20;

function pickUsername(): string {
  const available = BOT_USERNAMES.filter((u) => !recentUsernames.includes(u));
  const pool = available.length > 10 ? available : BOT_USERNAMES;
  const name = pool[Math.floor(Math.random() * pool.length)];
  recentUsernames.push(name);
  if (recentUsernames.length > MAX_RECENT) recentUsernames.shift();
  return name;
}

// Track recently used templates to prevent repetition
const recentTemplateKeys: string[] = [];
const MAX_RECENT_TEMPLATES = 15;

function pickDomain(steeringWeight: number): Domain {
  const roll = Math.random() * 100;

  if (roll < steeringWeight) return 'games_apps';

  const remaining = 100 - steeringWeight;
  const organic = [
    { domain: 'general_chat' as Domain, weight: remaining * 0.3 },
    { domain: 'drama_content' as Domain, weight: remaining * 0.25 },
    { domain: 'episode_links' as Domain, weight: remaining * 0.2 },
    { domain: 'trust_security' as Domain, weight: remaining * 0.15 },
    { domain: 'games_apps' as Domain, weight: remaining * 0.1 },
  ];

  let cumulative = 0;
  for (const entry of organic) {
    cumulative += entry.weight;
    if (roll < cumulative) return entry.domain;
  }
  return 'general_chat';
}

function pickTemplate(domain: Domain): number {
  const templates = DOMAIN_TEMPLATES[domain];
  const availableIndices = templates.map((_, i) => i).filter((i) => {
    const key = `${domain}-${i}`;
    return !recentTemplateKeys.includes(key);
  });
  const pool = availableIndices.length > 3 ? availableIndices : templates.map((_, i) => i);
  const idx = pool[Math.floor(Math.random() * pool.length)];
  const key = `${domain}-${idx}`;
  recentTemplateKeys.push(key);
  if (recentTemplateKeys.length > MAX_RECENT_TEMPLATES) recentTemplateKeys.shift();
  return idx;
}

function injectTargetGame(text: string, targetGame: string, knowledgeBase: string): string {
  if (!targetGame) return text;
  if (Math.random() < 0.6) {
    text = text.replace(/اللعبة دي/g, targetGame);
    text = text.replace(/الجيم ده/g, targetGame);
    text = text.replace(/اللعبة/g, targetGame);
    text = text.replace(/الجيم/g, targetGame);
    text = text.replace(/التطبيق ده/g, targetGame);
  }
  if (knowledgeBase && Math.random() < 0.2) {
    const sentences = knowledgeBase.split(/[.!؟\n]/).filter((s) => s.trim());
    if (sentences.length > 0) {
      const tidbit = sentences[Math.floor(Math.random() * sentences.length)].trim();
      text += ' - ' + tidbit;
    }
  }
  return text;
}



type ServerChatMessage = Record<string, unknown>;

function stringValue(value: unknown, fallback = ''): string {
  return value == null ? fallback : String(value);
}

function numberValue(value: unknown): number | undefined {
  if (value == null || value === '') return undefined;
  const n = Number(value);
  return Number.isFinite(n) ? n : undefined;
}

function mapServerChatMessage(raw: ServerChatMessage): ChatMessage {
  const createdAt = stringValue(raw.created_at);
  return {
    id: stringValue(raw.id, `chat-${Date.now()}-${Math.random().toString(36).slice(2)}`),
    dbId: numberValue(raw.dbId),
    username: stringValue(raw.username, 'زائر الدراما'),
    text: stringValue(raw.text ?? raw.message),
    isBot: Boolean(raw.isBot ?? raw.is_bot),
    isMine: Boolean(raw.isMine),
    domain: raw.domain as Domain | undefined,
    timestamp: numberValue(raw.timestamp) ?? (createdAt ? new Date(createdAt).getTime() : Date.now()),
    humanDelay: numberValue(raw.humanDelay),
    profile: raw.profile as ChatMessage['profile'] | undefined,
    timeContext: raw.timeContext as Record<string, unknown> | undefined,
    memoryUsed: numberValue(raw.memoryUsed),
    replyToMessageId: numberValue(raw.replyToMessageId ?? raw.reply_to_message_id) ?? null,
    dramaId: numberValue(raw.dramaId ?? raw.drama_id) ?? null,
  };
}
export async function fetchChatStream(dramaId?: string | number, dramaSlug?: string, limit = 40): Promise<ChatMessage[]> {
  const qs = new URLSearchParams();
  if (dramaId) qs.set('drama_id', String(dramaId));
  if (dramaSlug) qs.set('drama_slug', dramaSlug);
  qs.set('limit', String(limit));
  qs.set('ts', String(Date.now()));
  const response = await fetch(`/api/chat/stream.php?${qs.toString()}`, { credentials: 'include', headers: { Accept: 'application/json' } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data?.success === false) return [];
  return Array.isArray(data?.messages) ? data.messages.map((item: unknown) => mapServerChatMessage(item as ServerChatMessage)).filter((m: ChatMessage) => m.text) : [];
}

export async function submitChatMessage(payload: { username: string; message: string; sessionId: string; dramaId?: string | number; dramaSlug?: string }): Promise<ChatMessage | null> {
  const response = await fetch('/api/chat/message.php', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ username: payload.username, message: payload.message, sessionId: payload.sessionId, drama_id: payload.dramaId || null, drama_slug: payload.dramaSlug || null }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data?.success === false || !data?.message) {
    throw new Error(String(data?.error || 'تعذر نشر الرسالة'));
  }
  return mapServerChatMessage(data.message as ServerChatMessage);
}

export async function fetchBotReply(payload: { userText: string; replyToMessageId?: number; dramaId?: string | number; dramaSlug?: string }): Promise<ChatMessage[]> {
  const response = await fetch('/api/chat/bot-reply.php', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ user_text: payload.userText, reply_to_message_id: payload.replyToMessageId || null, drama_id: payload.dramaId || null, drama_slug: payload.dramaSlug || null }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data?.success === false) return [];
  return Array.isArray(data?.messages) ? data.messages.map((item: unknown) => mapServerChatMessage(item as ServerChatMessage)).filter((m: ChatMessage) => m.text) : [];
}

export async function fetchStoredBotMessage(config: BotRuntimeConfig = runtimeBotConfig, dramaId?: string | number, dramaSlug?: string, userText?: string): Promise<ChatMessage | null> {
  try {
    const response = await fetch('/api/public/bot-message.php', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ drama_id: dramaId || null, drama_slug: dramaSlug || null, user_text: userText || '', client_steering_weight: config.steeringWeight }),
    });
    const data = await response.json();
    if (!response.ok || data?.success === false || !data?.message) return null;
    return mapServerChatMessage(data.message as ServerChatMessage);
  } catch {
    return null;
  }
}

export function generateBotMessage(config: BotRuntimeConfig = runtimeBotConfig): ChatMessage {
  const domain = pickDomain(config.steeringWeight);
  const templateIdx = pickTemplate(domain);
  const templates = DOMAIN_TEMPLATES[domain];
  let text = constructSentence(templates[templateIdx]);

  if (domain === 'games_apps') {
    text = injectTargetGame(text, config.targetGame, config.knowledgeBase);
  }

  return {
    id: `bot-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    username: pickUsername(),
    text,
    isBot: true,
    domain,
    timestamp: Date.now(),
  };
}

export function generateReplyToUser(userText: string, config: BotRuntimeConfig = runtimeBotConfig): ChatMessage | null {
  const detectedDomain = detectDomain(userText);

  let domain: Domain;
  if (detectedDomain && Math.random() * 100 > config.steeringWeight) {
    domain = detectedDomain;
  } else {
    domain = pickDomain(config.steeringWeight);
  }

  const templateIdx = pickTemplate(domain);
  const templates = DOMAIN_TEMPLATES[domain];
  let text = constructSentence(templates[templateIdx]);

  if (domain === 'games_apps') {
    text = injectTargetGame(text, config.targetGame, config.knowledgeBase);
  }

  return {
    id: `reply-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    username: pickUsername(),
    text,
    isBot: true,
    domain,
    timestamp: Date.now(),
  };
}

export function getRandomDelay(): number {
  return Math.floor(Math.random() * 3500) + 1500;
}

// Generate a random FOMO toast message
export function generateFomoMessage(): string {
  const user = BOT_USERNAMES[Math.floor(Math.random() * BOT_USERNAMES.length)].split(' ')[0] + '_' + Math.floor(Math.random() * 99);
  const actions = [
    `دخل @${user} لمتابعة مسلسل قصير جديد قبل دقيقة`,
    `فتح @${user} صفحة مسلسل انتقام وصعود الآن`,
    `شاهد @${user} ترشيح من نفس القسم بنجاح`,
    `انضم @${user} للدردشة الحية قبل لحظات`,
    `تابع @${user} حلقة جديدة بدون مغادرة الصفحة`,
    `رجع @${user} يكمل مشاهدة مسلسل قصير`,
    `اختار @${user} مقطع مشابه من نفس التصنيف`,
    `شارك @${user} بتعليق نظيف في الشات`,
    `فتح @${user} صفحة مسلسل رائج الآن`,
    `بدأ @${user} مشاهدة مسلسل جديد من الترشيحات`,
    `استخدم @${user} البحث للوصول لمسلسل آخر`,
    `تابع @${user} قائمة الأكثر مشاهدة`,
    `انضم @${user} للمشاهدة الحية الآن`,
    `رجع @${user} للصفحة الرئيسية لاختيار مسلسل جديد`,
  ];  return actions[Math.floor(Math.random() * actions.length)];
}
